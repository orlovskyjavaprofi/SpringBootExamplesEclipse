package com.example.demo.Services;

import org.springframework.stereotype.Service;

@Service
public class NotificationService
{

	public NotificationService() {
		
	}
	
	public void send() {
		
	}
	
	public void sendAsync() {
		
	}
	
	@Override
	public String toString() {
		return "NotificationService{}";
	}
	
}
